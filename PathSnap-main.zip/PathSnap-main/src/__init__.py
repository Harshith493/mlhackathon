# PathSnap package initialization

